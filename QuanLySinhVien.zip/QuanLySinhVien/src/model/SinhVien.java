/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author pop
 */
public class SinhVien implements Serializable{
    private static int ID = 1;
    private int id;
    private String ten ;
    private int nhom;
    private String msv;

    public SinhVien() {
    }

    public SinhVien(String ten, int nhom, String msv) {
        id = ID++;
        this.ten = ten;
        this.nhom = nhom;
        this.msv = msv;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public int getNhom() {
        return nhom;
    }

    public void setNhom(int nhom) {
        this.nhom = nhom;
    }
 public String getMsv() {
        return msv;
    }

    public void setMsv(String msv) {
        this.msv = msv;
    }

    
}
