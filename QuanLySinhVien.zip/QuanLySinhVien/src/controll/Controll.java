/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controll;

import java.util.List;

/**
 *
 * @author pop
 */
public interface Controll {
    <T> void wrirte(List<T>list, String name);
    <T> List<T> read(String name);
}
